CREATE TABLE `Employees` (
  `idEmployees` int NOT NULL,
  `DateHired` datetime NOT NULL,
  `Salary` decimal(15,0) NOT NULL,
  `Username` varchar(45) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `Admin` tinyint NOT NULL,
  PRIMARY KEY (`idEmployees`),
  UNIQUE KEY `idEmployees_UNIQUE` (`idEmployees`),
  UNIQUE KEY `Username_UNIQUE` (`Username`)
);
CREATE USER 'empadmin'@'localhost' IDENTIFIED BY '12345';
GRANT SELECT, INSERT, DELETE, UPDATE ON nyc_inspections.Employees TO 'empadmin'@'localhost';
ALTER USER 'empadmin'@'localhost' IDENTIFIED BY '12345'; 
ALTER USER 'empadmin'@'localhost' IDENTIFIED WITH mysql_native_password BY '12345';
FLUSH privileges